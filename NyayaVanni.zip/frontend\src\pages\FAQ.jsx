import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import ThemeToggle from "../components/ThemeToggle";
import Footer from "../components/Footer";

export default function FAQ() {
  const navigate = useNavigate();
  const { language } = useLanguage();

  const faqs = [
    { q: "What file formats are supported?", a: "PDF, PNG, and JPG are supported." },
    { q: "Is NyayaVanni legal advice?", a: "No. It provides simplified explanations. Consult a lawyer for critical decisions." },
    { q: "How does it work?", a: "We extract text and use AI to summarize, detect risks, and answer questions." },
    { q: "Is my data secure?", a: "We follow standard security practices, but no system is fully risk-free." },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 px-6 py-6 transition-colors duration-300">
      <div className="max-w-4xl mx-auto flex flex-col min-h-[calc(100vh-3rem)]">
        
        {/* Navigation / Header */}
        <header className="flex items-center justify-between py-4 mb-8 border-b border-slate-200 dark:border-slate-800">
          <button 
            onClick={() => navigate(-1)} 
            className="flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-full border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 transition text-slate-700 dark:text-slate-200 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> {language === 'en' ? 'Back' : 'वापस'}
          </button>
          <ThemeToggle />
        </header>

        {/* Content */}
        <main className="flex-1">
          <h1 className="text-4xl font-extrabold text-slate-850 dark:text-white">FAQ</h1>
          <p className="text-slate-600 dark:text-slate-400 mt-3">Common questions about NyayaVanni.</p>

          <div className="mt-8 space-y-4">
            {faqs.map((item, idx) => (
              <details key={idx} className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/40 p-5 hover:border-slate-350 dark:hover:border-slate-700 transition duration-300 group">
                <summary className="cursor-pointer list-none flex items-center justify-between gap-4 font-semibold text-slate-850 dark:text-white">
                  <span>{item.q}</span>
                  <span className="text-slate-400 dark:text-slate-500 transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 text-slate-600 dark:text-slate-400 leading-relaxed text-sm">{item.a}</p>
              </details>
            ))}
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}